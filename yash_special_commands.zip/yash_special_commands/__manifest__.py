{
    "name": "Special Commands Test",
    "version": "14.0.1.0.0",
    "website": "https://www.youtube.com",
    "category": "Testing, Learning",
    "summary": """This module will demonstrate all special commands""",
    "description": "This module provides total analyses of your all orders",
    "depends": ["college"],
    "data": [
        "view/order_views.xml",
    ],
    "demo": [],
    "sequence": 2,
    "application": True,
    "installable": True,
    "auto-install": False,
}
